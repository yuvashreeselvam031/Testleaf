package SalesForceTestcase;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leafBot.testng.api.base.ProjectSpecificMethods;

import SalesForcePages.LoginPage;

public class Dashboard extends ProjectSpecificMethods{
	@BeforeTest
	public void setValues() {
		testCaseName = "Dashboard";
		testDescription = "Dashboard testCase using earth@testleaf.com UserName and LogOut";
		nodes = "Dashboard";
		authors = "Yuvashree";
		category = "Smoke";
		//dataSheetName = "TC001";
	}
	@Test
	public void toCreateNewChart() throws InterruptedException {
LoginPage lg = new LoginPage(driver, node);
		
		lg.enterUserName()
		.enterPassword()
		.clickLogin()
		 .clickToggleButton()
		 . clickViewAll() 
		 .clickServiceConsole()
		 .clickHome();
		

}
}
