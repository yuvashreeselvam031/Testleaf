package SalesForceTestcase;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leafBot.testng.api.base.ProjectSpecificMethods;

import SalesForcePages.LoginPage;

public class CreateNewChart extends ProjectSpecificMethods {

	@BeforeTest
	public void setValues() {
		testCaseName = "Create new chart";
		testDescription = "Login testCase using earth@testleaf.com UserName and LogOut";
		nodes = "Login";
		authors = "Yuvashree";
		category = "Smoke";
		//dataSheetName = "TC001";
	}
	@Test
	public void toCreateNewChart() throws InterruptedException {
LoginPage lg = new LoginPage(driver, node);
		
		lg.enterUserName()
		.enterPassword()
		.clickLogin()
		 .clickToggleButton()
		 . clickViewAll() 
		 .searchRefunds() 
		 .clickRefunds()
		 .clickRecentlyViewedDrpdwn()
		 .clickOnChartUnderNewButton()
		 .clickNewChart()
		 .enterChartName()
		 .selectChartType()
		 .selectAggregateType()
		 .selectAggregateField()
		 .selectGroupingField()
		 .clickSaveButtonInChart();
	}
}
