package SalesForcePages;
import com.leafBot.testng.api.base.ProjectSpecificMethods;
public class VerifyPage extends ProjectSpecificMethods {
	
public VerifyPage verifyRefundCreated() {
		
		verifyPartialText(locateElement("xpath", "//div[@class='slds-align-middle slds-hyphenate']"), "created");
		
		return this;
	}

}
