package SalesForcePages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {
	
	public HomePage(RemoteWebDriver driver, ExtentTest node){
		this.driver = driver;
		this.node = node;
			
	}

	public HomePage clickToggleButton() throws InterruptedException {
		// 2. Click on toggle menu button from the left corner
		Thread.sleep(10000);
		click(locateElement("xpath", "//div[@class='slds-icon-waffle']"));
	//	Thread.sleep(6000);
		return this;
	}

	public HomePage clickViewAll() {
		// 3. Click view All
		click(locateElement("xpath", "//button[text()='View All']"));
		return this;
	}
	
	 public HomePage searchRefunds() throws InterruptedException {
		 //4. Click on the drop down and select Refunds
		append(locateElement("xpath", "//h2[text()='App Launcher']/following::input"), "refunds");
		
		//sendKeyswithEnter1(locateElement("xpath", "//input[@type='search']"), "refunds", Keys.ENTER);
		return this;	
	}
	 public ServiceConsole clickRefunds() {
		// click refunds 
		 click(locateElement("xpath", "//mark[text()='Refunds']"));
		 return new ServiceConsole(driver, node);
	}
	 public HomePage searchServiceTerritories() {
		 //6) Click on Service Territories
		 append(locateElement("xpath", "//h2[text()='App Launcher']/following::input"), "service territories");
		return this;
	}
	 public NewServiceTerritory clickServiceTerritories() {
		 click(locateElement("xpath", "//mark[text()='Service Territories']"));
		 return new NewServiceTerritory(driver, node);
	}
	 public ServiceConsole clickServiceConsole() {
		 click(locateElement("xpath", "//p[text()='Service Console']"));
		 return new ServiceConsole(driver, node);

	}
	

}
