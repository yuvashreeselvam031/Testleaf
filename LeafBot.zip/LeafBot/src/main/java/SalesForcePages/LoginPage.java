package SalesForcePages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage(RemoteWebDriver driver, ExtentTest node){
		this.driver = driver;
		this.node = node;
			
	}
	
	public LoginPage enterUserName() {
	// enter username
		append(locateElement("id", "username"), "earth@testleaf.com");	
		return this;
	}
	
	public LoginPage enterPassword() {
		// enter password
		append(locateElement("id", "password"), "Bootcamp@123");
		return this;
	}
	
	public HomePage clickLogin() {
		click(locateElement("id", "Login"));
		return new HomePage(driver, node);
	}

}
