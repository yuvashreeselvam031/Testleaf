package SalesForcePages;

import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class HomeSalesForce extends ProjectSpecificMethods {

}
