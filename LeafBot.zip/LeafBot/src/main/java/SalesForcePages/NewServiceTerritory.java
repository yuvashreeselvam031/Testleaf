package SalesForcePages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class NewServiceTerritory extends ProjectSpecificMethods {
	public NewServiceTerritory(RemoteWebDriver driver, ExtentTest node){
		this.driver = driver;
		this.node = node;
			
	}
	public NewServiceTerritory clickNewInServiceTerritory() {
		click(locateElement("xpath", "//div[text()='New']"));
		return this;
	}
	
	public NewServiceTerritory enterNameInNameFieldOfServiceTerritory() throws InterruptedException {
        Thread.sleep(5000);
		append(locateElement("xpath", "//span[text()='Name']/following::input[@class=' input']"), "yuvashree");
		return this;
	}
	
	public NewServiceTerritory enterOperatingHours() {
		click(locateElement("xpath", "(//span[text()='Operating Hours']/following::div[@class='autocompleteWrapper slds-grow'])[2]"));
		click(locateElement("xpath", "//div[@class='primaryLabel slds-truncate slds-lookup__result-text']"));
		return this;
	}
	public NewServiceTerritory checkActivityField() {
		click(locateElement("xpath", "//span[text()='Active']/following::input[@type='checkbox']"));
		return this;	
	}
	public NewServiceTerritory enterCity() {
		append(locateElement("xpath", "//span[text()='City']/following::input"), "Chennai");
		return this;
	}
	public NewServiceTerritory enterState() {
		append(locateElement("xpath", "//span[text()='State/Province']/following::input"), "Tamilnadu");
		return this;
	}
	public NewServiceTerritory enterCountry() {
		append(locateElement("xpath","//span[text()='Country']/following::input"), "India");
		return this;
	}
	public NewServiceTerritory enterZipCode() {
		append(locateElement("xpath", "//span[text()='Zip/Postal Code']/following::input"), "600052");
		return this;
	}
	public void clickSaveInServiceTerritory() {
		click(locateElement("xpath", "(//span[text()='Save'])[2]"));

	}

}
