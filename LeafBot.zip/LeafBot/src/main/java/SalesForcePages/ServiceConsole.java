package SalesForcePages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;import freemarker.cache.TemplateLookupContext;

public class ServiceConsole extends ProjectSpecificMethods {
	public ServiceConsole(RemoteWebDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;

	}

	public ServiceConsole clickNew() {
		click(locateElement("xpath", "//div[text()='New']"));
		return this;
	}

	public ServiceConsole enterAccountInServiceConsole() {

		click(locateElement("xpath", "//div[@title='yuvashree']"));
		/*
		 * sendKeyswithEnter1( locateElement("xpath",
		 * 
		 * "//input[@class=' default input uiInput uiInputTextForAutocomplete uiInput--default uiInput--input uiInput uiAutocomplete uiInput--default uiInput--lookup']"
		 * ),"yuvashree", Keys.ENTER);
		 */
		// (//span[text()='Account']/following::div[@class='contentWrapper
		// slds-box--border'])
		// input[@class=' default input uiInput uiInputTextForAutocomplete
		// uiInput--default uiInput--input uiInput uiAutocomplete uiInput--default
		// uiInput--lookup']
		return this;
	}

	public ServiceConsole changeStatusAsCancelled() {
		// 7. Select Status as Canceled
		click(locateElement("xpath", "//a[@class='select']"));
		click(locateElement("xpath", "//a[text()='Canceled']"));
		return this;
	}

	public ServiceConsole enterAmountInRefund() {
		// 8. Give Amount as 50000 and select Referenced in Type
		append(locateElement("xpath", "//span[text()='Amount']/following::input[@class='input uiInputSmartNumber']"),
				"50000");
		return this;
	}

	public ServiceConsole changeType() throws InterruptedException {
		// TODO Auto-generated method stub
		click(locateElement("xpath", "(//span[text()='Type']/following::a[@class='select'])[2]"));
		Thread.sleep(5000);
		click(locateElement("xpath", "//a[@title='Referenced']"));
		return this;
	}

	public ServiceConsole changeProcessingMode() {
		click(locateElement("xpath", "//span[text()='Processing Mode']/following::a"));
		click(locateElement("xpath", "//a[@title='External']"));
		return this;
	}

	public VerifyPage clickSaveButtonInRefund() {
		click(locateElement("xpath",
				"//button[@class='slds-button slds-button--neutral uiButton--brand uiButton forceActionButton']"));
		return new VerifyPage();
	}

	public ServiceConsole clickRecentlyViewedDrpdwn() {
		// 5.Click on drop down near Recently viewed and change into 'All'.
		click(locateElement("xpath",
				"//lightning-icon[@class='slds-button__icon slds-icon-utility-down slds-icon_container forceIcon']"));
		click(locateElement("xpath", "//div[text()='List Views']/following::span[2]"));
		return this;
	}

	public ServiceConsole clickOnChartUnderNewButton() {
		// 6. Click on Chart icon under New Button
		click(locateElement("xpath", "//button[@class='slds-button slds-button_icon slds-button_icon-border-filled slds-button_first']"));
		return this;

	}

	public ServiceConsole clickNewChart() {
		// 7. Click New Chart
		click(locateElement("xpath", "//lightning-icon[@class='slds-button__icon slds-icon-utility-settings slds-icon_container forceIcon']"));
		click(locateElement("xpath", "//li[@class='uiMenuItem']/a[@title='Delete Chart']"));
		click(locateElement("xpath", "//span[text()='Delete']"));
		click(locateElement("xpath", "//span[text()='New Chart']"));
		return this;
	}
	public ServiceConsole enterChartName() {
        //8. Give Chart Name and Select Chart Type
		append(locateElement("xpath", "//label[text()='Chart Name']/following::input"), "yuvashree");
		return this;
	}
	
	public ServiceConsole selectChartType() {
		// TODO Auto-generated method stub
		click(locateElement("xpath", "//span[text()='Chart Type']/following::a"));
		click(locateElement("xpath", "//li[@class='uiMenuItem uiRadioMenuItem']/a[@title='Donut Chart']"));
		//WebElement locateElement = locateElement("xpath", "//span[text()='Chart Type']/following::a");
		//locateElement.sendKeys(Keys.ARROW_DOWN.ARROW_DOWN.ENTER);
	//	click(locateElement("xpath", "//a[title='Vertical Bar Chart']"));
		return this;

	}
	public ServiceConsole selectAggregateType() {
		// TODO Auto-generated method stub
		click(locateElement("xpath", "//span[text()='Aggregate Type']/following::a"));
		click(locateElement("xpath", "//li[@class='uiMenuItem uiRadioMenuItem']/a[@title='Average']"));
		return this;
	}
	public ServiceConsole selectAggregateField() {
		//9. Select Aggregate Type as Average and ggregate Field as Amount
		click(locateElement("xpath", "//span[text()='Aggregate Field']/following::a"));
		click(locateElement("xpath", "//li[@class='uiMenuItem uiRadioMenuItem']/a[@title='Amount']"));
		return this;
	}
	public ServiceConsole selectGroupingField() {
        //10. Select Grouping Field as Account and click Save
		click(locateElement("xpath", "//span[text()='Grouping Field']/following::a"));
		click(locateElement("xpath", "//li[@class='uiMenuItem uiRadioMenuItem']/a[@title='Account']"));
		return this;
	}
    public ServiceConsole clickSaveButtonInChart() {
    	//11. Click on settings icon and change the Chart Type
		click(locateElement("xpath", "(//span[text()='Save'])[2]"));
		return this;
	}
    public HomeSalesForce clickHome() {
    	click(locateElement("xpath", "//span[text()='Home']"));
    	return new HomeSalesForce();

	}

	
}
