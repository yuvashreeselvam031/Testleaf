package SalesForcePages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {

	public HomePage clickToggleButton() throws InterruptedException {
		// 2. Click on toggle menu button from the left corner
		Thread.sleep(10000);
		click(locateElement("class", "slds-icon-waffle"));
	//	Thread.sleep(6000);
		return this;
	}

	public HomePage clickViewAll() {
		// 3. Click view All
		click(locateElement("xpath", "//button[text()='View All']"));
		return this;
	}
	 public HomePage searchRefunds() {
		 //4. Click on the drop down and select Refunds
		 append(locateElement("xpath", "//input[@placeholder='Search apps and items...']"), "refunds");
		 sendKeyswithEnter1(locateElement("xpath", "//input[@placeholder='Search apps and items...']"), "refunds", Keys.ENTER);
		return this;	
	}
	 public HomePage clickRefunds() {
		// click refunds 
		 click(locateElement("xpath", "//p[@class='slds-truncate']"));
		 return this;

	}

}
